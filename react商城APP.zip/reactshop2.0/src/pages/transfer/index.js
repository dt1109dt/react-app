import React from 'react';
const Transfer=()=>{
    return (
        <React.Fragment></React.Fragment>
    )
}
export default Transfer;