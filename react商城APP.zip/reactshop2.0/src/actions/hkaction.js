function addHistoryKeywords(data){
    return {
        type:"addHk",
        data:data
    }
}
export{
    addHistoryKeywords
}